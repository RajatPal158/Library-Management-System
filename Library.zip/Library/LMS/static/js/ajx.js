$(document).ready(function(){
    $("#book_submit").submit(function (e){
        e.preventDefault();
        $.ajax({
            type:'POST',
            url:'/s_book_issue_2/',
            data:{
              book_no : $('#b_no').val(),
              roll_no : $('#st_roll_no').val(),
              csrfmiddlewaretoken : $('input[name=csrfmiddlewaretoken]').val()
            },
            success:function(response){
                if(response == 'issue'){
                    alert("Book Issued Successfully.");
                    location.reload();
                }
                else if(response == 'already_issued'){
                    $("#b_no").css("border","1px solid red");
                    $("#error").text("This Book is already Issued.");
                    $("#b_no").keyup(function(){
                    res = $("#b_no").val();
                        if(res == ""){
                            $("#b_no").css("border","");
                            $("#error").text("");
                        }
                    });
                }
                else if(response == 'wrong_data'){
                    $("#b_no").css("border","1px solid red");
                    $("#error").text("Please enter correct Book Number.");
                    $("#b_no").keyup(function(){
                    res = $("#b_no").val();
                        if(res == ""){
                            $("#b_no").css("border","");
                            $("#error").text("");
                        }
                    });
                }
            }
        });
    });
    $("#book_return").submit(function (e){
        e.preventDefault();
        $.ajax({
            type:'POST',
            url:'/s_return_book_2/',
            data:{
              book_no : $('#b_no').val(),
              roll_no : $('#st_roll_no').val(),
              csrfmiddlewaretoken : $('input[name=csrfmiddlewaretoken]').val()
            },
            success:function(response){
                if(response == 'returned'){
                    alert("Book Returned Successfully.");
                    location.reload();
                }
                else if(response == 'not_this_user'){
                    $("#b_no").css("border","1px solid red");
                    $("#error").text("This Book is not Issue to this User.");
                    $("#b_no").keyup(function(){
                    res = $("#b_no").val();
                        if(res == ""){
                            $("#b_no").css("border","");
                            $("#error").text("");
                        }
                    });
                }
                else if(response == 'not_issued'){
                    $("#b_no").css("border","1px solid red");
                    $("#error").text("This Book is not Issue to any User.");
                    $("#b_no").keyup(function(){
                    res = $("#b_no").val();
                        if(res == ""){
                            $("#b_no").css("border","");
                            $("#error").text("");
                        }
                    });
                }
                else if(response == 'wrong_data'){
                    $("#b_no").css("border","1px solid red");
                    $("#error").text("Please enter correct Book Number.");
                    $("#b_no").keyup(function(){
                    res = $("#b_no").val();
                        if(res == ""){
                            $("#b_no").css("border","");
                            $("#error").text("");
                        }
                    });
                }
            }
        });
    });
});